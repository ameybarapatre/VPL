<?php

for($i=140;$i<365;$i++){ $dir = "c:/xampp/htdocs/pl1/".$i."/";
if ($handle = opendir($dir)) {
    while (false !== ($fileName = readdir($handle))) {
        
        $newName="1.jpg";
        echo $fileName;
        rename($dir.$fileName,$dir.$newName);
    }
    closedir($handle);
}}
echo "done"
?>